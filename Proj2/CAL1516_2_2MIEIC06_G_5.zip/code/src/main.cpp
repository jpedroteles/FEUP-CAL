/*
 * main.cpp
 */

#include "graphviewer.h"
#include "Graph.h"
#include "street.h"
#include "POI.h"
#include "utils.h"
#include "way.h"
#include "menu.h"

using namespace std;

int main() {
	welcome();
	return 0;
}
